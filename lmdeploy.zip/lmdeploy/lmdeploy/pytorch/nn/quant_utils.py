# Copyright (c) OpenMMLab. All rights reserved.
from lmdeploy.lite.quantization.weight.quant_utils import quant_blocked_fp8  # noqa: F401
