# Copyright (c) OpenMMLab. All rights reserved.
from abc import abstractmethod
from typing import List

import torch

def get_sm_version():
    prop = torch.cuda.get_device_properties(0)
    return prop.major * 10 + prop.minor

def preprocess_weights_for_mixed_gemm(tensor: torch.Tensor,
                                      quant_mode: torch.dtype,
                                      act_dtype: torch.dtype,
                                      sm_: int = -1) -> torch.Tensor:
    sm_ = sm_ if sm_ > 0 else get_sm_version()
    if len(tensor.shape) == 2:
        tensor = tensor.unsqueeze(0)
    elif sm_ >= 90:
        sm_ = 80
    if sm_ >= 120:
        sm_ = 80

    permutation_map = {
        "16_8": [0, 1, 8, 9, 2, 3, 10, 11, 4, 5, 12, 13, 6, 7, 14, 15],
        "16_4": [
            0, 1, 8, 9, 16, 17, 24, 25, 2, 3, 10, 11, 18, 19, 26, 27, 4, 5, 12,
            13, 20, 21, 28, 29, 6, 7, 14, 15, 22, 23, 30, 31
        ],
        "8_4": [
            0, 1, 2, 3, 16, 17, 18, 19, 4, 5, 6, 7, 20, 21, 22, 23, 8, 9, 10,
            11, 24, 25, 26, 27, 12, 13, 14, 15, 28, 29, 30, 31
        ]
    }

    # permute_B_rows_for_mixed_gemm
    BITS_PER_ELT_A = 8 if act_dtype == torch.float8_e4m3fn else 16
    BITS_PER_ELT_B = 4 if quant_mode == torch.quint4x2 else 8
    MMA_SHAPE_N = 8
    B_ROWS_PER_MMA = 8 * 16 // BITS_PER_ELT_B

    num_experts = tensor.shape[0]
    num_rows = tensor.shape[1]
    num_cols = tensor.shape[2]

    assert (sm_ >= 75)
    assert (num_rows % B_ROWS_PER_MMA == 0)
    assert (num_cols % MMA_SHAPE_N == 0)

    row_idx_list = [
        (row_idx // B_ROWS_PER_MMA) * B_ROWS_PER_MMA +
        permutation_map[f"{BITS_PER_ELT_A}_{BITS_PER_ELT_B}"][row_idx %
                                                              B_ROWS_PER_MMA]
        for row_idx in range(num_rows)
    ]
    tensor = tensor[:, row_idx_list, :]

    # subbyte_transpose
    original_shape = tensor.shape
    if BITS_PER_ELT_B == 4:
        tensor = tensor.view(torch.uint8)
        high_tensor = (tensor >> 4).permute(0, 2, 1).unsqueeze(2)
        low_tensor = ((tensor << 4) >> 4).permute(0, 2, 1).unsqueeze(2)
        new_tensor = torch.cat([low_tensor, high_tensor],
                               dim=2).reshape(tensor.shape[0], -1,
                                              tensor.shape[1])
        new_tensor = new_tensor[:, :, 0::2] + new_tensor[:, :, 1::2] * 16
        tensor = new_tensor.view(torch.int8).reshape(original_shape)
    else:
        tensor = tensor.permute(0, 2, 1).reshape(original_shape)

    # interleave_column_major_tensor
    interleave = BITS_PER_ELT_A // BITS_PER_ELT_B
    if interleave > 1 and sm_ < 90:
        rows_per_tile = 128 * 8 // BITS_PER_ELT_A
        elts_in_int32 = 32 // BITS_PER_ELT_B

        assert (num_rows % elts_in_int32 == 0)
        assert (num_rows % rows_per_tile == 0)

        tensor = tensor.reshape(num_experts, -1, interleave,
                                num_rows // rows_per_tile,
                                rows_per_tile * 4 // elts_in_int32)
        tensor = tensor.permute(0, 1, 3, 2, 4).reshape(original_shape)

    # add_bias_and_interleave_quantized_tensor_inplace
    if BITS_PER_ELT_B == 8:
        tensor += -256 * (tensor > 127).byte() + 128
        tensor = tensor.reshape(-1, 4)[:, [0, 2, 1, 3]].reshape(tensor.shape)
    elif BITS_PER_ELT_B == 4:
        tensor = tensor.view(torch.uint8)
        high_tensor = (tensor >> 4).unsqueeze(-1)
        low_tensor = ((tensor << 4) >> 4).unsqueeze(-1)
        new_tensor = torch.cat([low_tensor, high_tensor],
                               dim=-1).reshape(tensor.shape[0], tensor.shape[1],
                                               -1)
        new_tensor = new_tensor.reshape(
            -1, 8)[:, [0, 2, 4, 6, 1, 3, 5, 7]].reshape(new_tensor.shape)
        new_tensor += -16 * (new_tensor > 7).byte() + 8
        new_tensor = new_tensor[:, :, 0::2] + new_tensor[:, :, 1::2] * 16
        tensor = new_tensor.view(torch.int8)
    else:
        raise NotImplementedError

    return tensor.squeeze(0).contiguous()

def ensure_i4_uint8(tensors: torch.Tensor):
    """Ensure tensors in i4 with uint8 format."""
    result = []
    for tensor in tensors:
        if tensor is not None:
            assert tensor.dtype == torch.uint8
            result.append(tensor)
        else:
            result.append(None)
    return (*result, )

def ensure_fp8(tensors: torch.Tensor):
    """Ensure tensors in fp8_e4m3fn format."""
    result = []
    for tensor in tensors:
        if tensor is not None:
            assert tensor.dtype == torch.uint8
            result.append(tensor)
        else:
            result.append(None)
    return (*result, )


def ensure_fp32(tensors: torch.Tensor):
    """Ensure tensors in fp32 format."""
    result = []
    for tensor in tensors:
        if tensor is not None:
            assert tensor.dtype == torch.float32
            result.append(tensor)
        else:
            result.append(None)
    return (*result, )


def requantize_qkv(weights: List[torch.Tensor],
                   scales: List[torch.Tensor]):
    # Credit to: https://github.com/vllm-project/vllm/pull/4332#issuecomment-2085560821
    device_q, device_k, device_v = [tensor.device for tensor in weights]
    wq, wk, wv = [tensor.view(dtype=torch.float8_e4m3fn).cpu() if tensor.is_cuda else tensor for tensor in weights]
    wq_scale, wk_scale, wv_scale = [s.cpu() if s.is_cuda else s for s in scales]

    w_scale = max(wq_scale, wk_scale, wv_scale)
    qw = ((wq_scale / w_scale) * wq).view(dtype=torch.uint8).to(device_q)
    kw = ((wk_scale / w_scale) * wk).view(dtype=torch.uint8).to(device_k)
    vw = ((wv_scale / w_scale) * wv).view(dtype=torch.uint8).to(device_v)
    return qw, kw, vw, w_scale.to(device_q)


def fused_w1w3(w1: torch.Tensor, w3: torch.Tensor, tp: int, dim: int):

    def reshape(x):
        return x.view(x.size(0), tp, -1) if dim == 2 else x.view(tp, -1)

    device = w1.device
    if w1.is_cuda and w1.dtype == torch.uint8:
        w1 = w1.view(dtype=torch.float8_e4m3fn).cpu()
    if w3.is_cuda and w3.dtype == torch.uint8:
        w3 = w3.view(dtype=torch.float8_e4m3fn).cpu()

    # w1 means gate, w3 means up
    w31 = torch.cat((reshape(w3), reshape(w1)), dim=0)

    if w31.is_cpu:
        w31 = w31.view(dtype=torch.uint8).to(device)

    # (2 * inter_size, hidden_dim)
    return w31.view(-1, w1.size(1))


def identity(x):
    return x

def inv(x):
    return torch.reciprocal(x)

def to_half(x: torch.Tensor):
    return x.to(torch.half)


def to_float(x: torch.Tensor):
    return x.to(torch.float)

def to_fp32(x: torch.Tensor):
    return x.to(torch.float32)

def to_fp8(x: torch.Tensor):
    assert x.dtype == torch.uint8
    return x.view(dtype=torch.float8_e4m3fn)


def pack_u4_row(x: torch.Tensor) -> torch.Tensor:
    assert x.dtype == torch.uint8
    xs = x.view(*x.shape[:-1], -1, 8).split(1, dim=-1)
    a = torch.zeros(xs[0].shape, dtype=torch.int32, device=x.device)
    for t in reversed(xs):
        a = (a << 4) | t
    return a.squeeze(dim=-1)

class Parameter:
    KEY = ()

    @classmethod
    def take(cls, keys: List[str]):
        if not any(k.endswith(cls.KEYS[0]) for k in keys):
            return False
        xs = []
        for k in keys:
            if any(k.endswith(p) for p in cls.KEYS):
                xs.append(k)
        for x in xs:
            keys.remove(x)
        return True

    @abstractmethod
    def __call__(cls, f, g, i):
        pass


class QuantWeightOnly(Parameter):
    KEYS = '.qweight', '.scales', '.qzeros'

    def __call__(self, f, g, i):
        f(i, g('qweight'), 'qweight', pack_u4_row)
        f(i, g('scales'), 'scales', to_half, apply_gs=True)
        f(i, g('qzeros'), 'zeros', to_half, apply_gs=True)


class QuantWeightFP8(Parameter):
    KEYS = '.qweight', '.weight_scale', '.input_scale'

    def __call__(self, f, g, i, module_type=None):
        if module_type == 'attn':
            # attn, per-tensor, only one scale
            qw, kw, vw, ow = ensure_fp8(g('qweight'))
            q_s, k_s, v_s, o_s = ensure_fp32(g('weight_scale'))
            q_is, k_is, v_is, o_is = ensure_fp32(g('input_scale'))
            assert torch.equal(q_is, k_is) and torch.equal(q_is, v_is), \
                "The input scale for q, k, v are not equal!"

            # requantize the separately quantized q, k, v weights to share with
            # a single weight scale.
            wq, wk, wv, qkv_s = requantize_qkv([qw, kw, vw], [q_s, k_s, v_s])
            qkvo = wq, wk, wv, ow

            qkv_weight_scale_inv = torch.reciprocal(qkv_s)
            qkv_input_scale_inv = torch.reciprocal(q_is)
            
            o_weight_scale_inv = torch.reciprocal(o_s)
            o_input_scale_inv = torch.reciprocal(o_is)

            # '.qweight', '.weight_scale', '.input_scale', 
            # '.input_scale_inv', '.weight_scale_inv', '.host_input_scale_inv'
            # qweight for qkv and o
            f(i, qkvo, 'qweight', identity)
            # scales for qkv
            f(i, qkv_s.unsqueeze(0), 'w_qkv.weight_scale', to_float)
            f(i, q_is.unsqueeze(0), 'w_qkv.input_scale', to_float)
            f(i, qkv_input_scale_inv.unsqueeze(0), 'w_qkv.input_scale_inv', to_float)
            f(i, qkv_input_scale_inv.unsqueeze(0), 'w_qkv.host_input_scale_inv', to_float)
            f(i, qkv_weight_scale_inv.unsqueeze(0), 'w_qkv.weight_scale_inv', to_float)
            
            # scales for o
            f(i, o_s.unsqueeze(0), 'wo.weight_scale', to_float)
            f(i, o_is.unsqueeze(0), 'wo.input_scale', to_float)
            f(i, o_input_scale_inv.unsqueeze(0), 'wo.input_scale_inv', to_float)
            f(i, o_input_scale_inv.unsqueeze(0), 'wo.host_input_scale_inv', to_float)
            f(i, o_weight_scale_inv.unsqueeze(0), 'wo.weight_scale_inv', to_float)
        elif module_type == 'ffn':
            # qweight, weight_scale and input_scale for w1, w2 and w3
            f(i, ensure_fp8(g('qweight')), 'qweight', identity)
            f(i, ensure_fp32(g('weight_scale')), 'weight_scale', to_float)
            f(i, ensure_fp32(g('input_scale')), 'input_scale', to_float)
            f(i, ensure_fp32(g('input_scale')), 'input_scale_inv', inv)
            f(i, ensure_fp32(g('input_scale')), 'host_input_scale_inv', inv)
            f(i, ensure_fp32(g('weight_scale')), 'weight_scale_inv', inv)
        else:
            raise ValueError(f"Module type {module_type} is not support!")

import numpy as np
def unpack_int4_from_uint8(packed_tensor):
    # 将 tensor 转移到 CPU 并转换为 numpy 数组
    packed_array = packed_tensor.cpu().numpy()

    # 创建一个用于存储拆分后 int4 数据的列表
    unpacked_data = []

    # 遍历打包后的每个 uint8 数据
    for uint8_val in packed_array.flat:
        # 提取高 4 位的 int4 数据
        high_int4 = (uint8_val >> 4) & 0x0F
        # 提取低 4 位的 int4 数据
        low_int4 = uint8_val & 0x0F
        # 将拆分后的数据追加到列表中
        unpacked_data.append(high_int4)
        unpacked_data.append(low_int4)

        # 只打印前10个数据
        if len(unpacked_data) >= 20:
            break

    # 将拆分后的数据转换为 numpy 数组并打印
    unpacked_array = np.array(unpacked_data, dtype=np.int8)
    # print("拆分后的 int4 数据:")
    # print(unpacked_array)
    return unpacked_array

class QuantWeightW4A8AWQ(Parameter):
    KEYS = '.weight', '.weight_scale', '.weight_scale_2', '.pre_quant_scale', '.input_scale'

    def __call__(self, f, g, i, module_type=None):
        if module_type == 'attn':
            # attn, per-tensor, only one scale
            qw, kw, vw, ow = ensure_i4_uint8(g('weight'))
            q_ws, k_ws, v_ws, o_ws = ensure_fp32(g('weight_scale'))
            q_ws2, k_ws2, v_ws2, o_ws2 = ensure_fp32(g('weight_scale_2'))
            q_is, k_is, v_is, o_is = ensure_fp32(g('input_scale'))
            o_pqs = g('pre_quant_scale')
            assert torch.equal(q_is, k_is) and torch.equal(q_is, v_is), \
                "The input scale for q, k, v are not equal!"
            
            # NOTE(Alan): for model opt w4a8 quant qkv fp8 weight scale is equal
            assert torch.equal(q_ws2, k_ws2) and torch.equal(q_ws2, v_ws2), \
                "The weight scale for q, k, v are not equal!"

            # qweight for qkv and o
            qkvo = qw, kw, vw, ow
            # TODO: 是否需要在此进行pack
            f(i, qkvo, 'qweight', identity)

            # NOTE(Alan): q_ws2 and k_ws2 need permute
            # print("--- dont permute_v2 q_ws/k_ws now ----")
            # q_ws = permute_v2(q_ws.T, 128).T
            # k_ws = permute_v2(k_ws.T, 128).T

            # Note(meng): Temporary, only the concatenation of qkv scales is performed.
            # print(f"qkv shape: {q_ws2.shape} {k_ws2.shape} {v_ws2.shape}")
            # w_qkv_weight_scale = torch.cat((q_ws, k_ws, v_ws), dim=0)
            w_qkv_weight_scale_2 = q_ws2.unsqueeze(0)
            w_qkv_input_scale = q_is.unsqueeze(0)

            #w_qkv_weight_scale = w_qkv_weight_scale.transpose(-1, -2)
            #o_ws = o_ws.transpose(-1, -2)

            f(i, w_qkv_weight_scale_2, 'w_qkv.weight_scale_2', to_fp32)
            f(i, w_qkv_input_scale, 'w_qkv.input_scale', to_fp32)
            
            qkv_weight_scale_inv = torch.reciprocal(q_ws2)
            qkv_input_scale_inv = torch.reciprocal(q_is)
            f(i, qkv_input_scale_inv.unsqueeze(0), 'w_qkv.input_scale_inv', to_float)
            f(i, qkv_input_scale_inv.unsqueeze(0), 'w_qkv.host_input_scale_inv', to_float)
            f(i, qkv_weight_scale_inv.unsqueeze(0), 'w_qkv.weight_scale_inv', to_float)
            
            w_qkv_weight_scale = q_ws, k_ws, v_ws
            f(i, w_qkv_weight_scale, 'w_qkv.weight_scale', identity)

            f(i, o_ws2.unsqueeze(0), 'wo.weight_scale_2', to_fp32)
            f(i, o_is.unsqueeze(0), 'wo.input_scale', to_fp32)
            
            # TODO(Alan): o_pqs is tuple with [None, None, None, Tensor]
            f(i, o_pqs[-1], 'wo.pre_quant_scale', identity)
            f(i, o_ws.squeeze(0), 'wo.weight_scale', identity)
            
            o_weight_scale_inv = torch.reciprocal(o_ws2)
            o_input_scale_inv = torch.reciprocal(o_is)
            f(i, o_input_scale_inv.unsqueeze(0), 'wo.input_scale_inv', to_float)
            f(i, o_input_scale_inv.unsqueeze(0), 'wo.host_input_scale_inv', to_float)
            f(i, o_weight_scale_inv.unsqueeze(0), 'wo.weight_scale_inv', to_float)
        elif module_type == 'ffn':
            w1_ws, w2_ws, w3_ws = ensure_fp32(g('weight_scale'))
            w1_ws = w1_ws.transpose(-1, -2)
            w2_ws = w2_ws.transpose(-1, -2)
            w3_ws = w3_ws.transpose(-1, -2)

            # qweight, weight_scale and input_scale for w1, w2 and w3
            f(i, ensure_i4_uint8(g('weight')), 'qweight', identity)
  
            f(i, ensure_fp32(g('weight_scale_2')), 'weight_scale_2', to_fp32)
            f(i, ensure_fp32(g('input_scale')), 'input_scale', to_fp32)
            #f(i, g('pre_quant_scale'), 'pre_quant_scale', identity)

            # NOTE(Alan): weight scale
            f(i, ensure_fp32((w1_ws, w2_ws, w3_ws)), 'weight_scale', identity)
            h1 = g('pre_quant_scale')[0] != None
            h2 = g('pre_quant_scale')[1] != None
            h3 = g('pre_quant_scale')[2] != None
            #f(i, g('pre_quant_scale'), 'pre_quant_scale', identity)
            f(i, g('pre_quant_scale'), 'pre_quant_scale', identity, has_value=(h1, h2, h3))
            
            f(i, ensure_fp32(g('input_scale')), 'input_scale_inv', inv)
            f(i, ensure_fp32(g('input_scale')), 'host_input_scale_inv', inv)
            f(i, ensure_fp32(g('weight_scale_2')), 'weight_scale_inv', inv)
        else:
            raise ValueError(f"Module type {module_type} is not support!")

class WeightScaleInv(Parameter):
    KEYS = '.weight_scale_inv', '.weight'

    # TODO: flag any operations crossing the quant blocks as illegal
    def __call__(self, f, g, i):
        f(i, g('weight_scale_inv'), 'scales', to_float, block_size=128)
        f(i, g('weight'), 'weight', identity)


class Weight(Parameter):
    KEYS = '.weight',

    def __call__(self, f, g, i):
        f(i, g('weight'), 'weight', identity)


class Bias(Parameter):
    KEYS = '.bias',

    def __call__(self, f, g, i):
        f(i, g('bias'), 'bias', identity)


class PLora(Parameter):
    KEYS = '.Plora_A.weight', '.Plora_B.weight'

    def __call__(self, f, g, i):
        f(i, g('Plora_A.weight'), 'lora_a.weight', identity)
        f(i, g('Plora_B.weight'), 'lora_b.weight', identity)


class MergedMoeParameter(Parameter):
    KEYS = 'experts.down_proj', 'experts.gate_up_proj'
    def __call__(self, f, g, i):
        # inter_size: int, fmt: str, idx: int, w123, kind: str
        f(i, g(), 'weight', identity)

def get_params(keys: List[str], bias=0, model_format=None, quant_algo=None):
    ps = []
    if PLora.take(keys):
        ps.append(PLora())
    if model_format == 'fp8' and quant_algo == 'fp8_static':
        if QuantWeightFP8.take(keys):
            ps.append(QuantWeightFP8())
    elif model_format == 'w4a8_awq' and quant_algo == 'w4a8_awq':
        if QuantWeightW4A8AWQ.take(keys):
            ps.append(QuantWeightW4A8AWQ())
    else:
        if QuantWeightOnly.take(keys):
            ps.append(QuantWeightOnly())
    if WeightScaleInv.take(keys):
        ps.append(WeightScaleInv())
    if Weight.take(keys):
        ps.append(Weight())
    if bias and Bias.take(keys):
        ps.append(Bias())
    return ps

def get_mergedmoe_params(keys: List[str], bias=0, model_format=None, quant_algo=None):
    ps = []
    if PLora.take(keys):
        ps.append(PLora())
    if model_format == 'fp8' and quant_algo == 'fp8_static':
        if QuantWeightFP8.take(keys):
            ps.append(QuantWeightFP8())
    else:
        if QuantWeightOnly.take(keys):
            ps.append(QuantWeightOnly())
    if WeightScaleInv.take(keys):
        ps.append(WeightScaleInv())

    if MergedMoeParameter.take(keys):
        ps.append(MergedMoeParameter())
    if bias and Bias.take(keys):
        ps.append(Bias())
    return ps
