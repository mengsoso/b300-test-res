# Copyright (c) OpenMMLab. All rights reserved.
from .data_type import MultiModalData, MultiModalTensor

__all__ = ['MultiModalData', 'MultiModalTensor']
