# Copyright (c) OpenMMLab. All rights reserved.
from .cli import run

if __name__ == '__main__':
    run()
