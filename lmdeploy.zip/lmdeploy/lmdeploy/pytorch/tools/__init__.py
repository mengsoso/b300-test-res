# Copyright (c) OpenMMLab. All rights reserved.
from .utils import Timer  # noqa: F401
