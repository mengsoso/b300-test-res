#!/user/bin/env bash
################################################################################
# @Copyright: 2024 Shopee. All Rights Reserved.
# @Author   : zhen.wan@shopee.com
# @Date     : 2024-04-15 10:47:20
# @Details  : benchmark test script for LMDeploy, VLLM and TensorRT-LLM backend.
# @Update   : update parameter for support vlm and llm benchmark
################################################################################
set -euxo pipefail

usage() {
cat << EOF
    Usage: All options are needed!
     -p: model path
     -f: test data path
     -d: device_id(0 or 0,1 or 2,3 or 0,1,2,3)
     -m: model_type(llm/vlm)
     -b: backend(lmdeploy/vllm/tensorrt-llm")
     -h: hardware(v100,h100, no practical significance, only used for record-keeping)
     -t: datatype(fp16,fp8, needs to be aligned with the model, has no practical significance, only used for recording)



     An example of using RandomDataset:
     bash run_benchmark.sh -p Qwen/Qwen3-8B  -m llm -f dummy -d 1  -b vllm -h h100 -t fp16

     Default Settings (specify dataset) example:
     bash run_benchmark.sh -p Qwen/Qwen3-8B  -m llm -f ./test_data/data.csv -d 1  -b vllm -h h100 -t fp16

     RandomDataset pattern description:
      -When the -f parameter is set to "dummy", the RandomDataset is automatically used for synthetic data testing
      -It can automatically test multiple combinations of input lengths (512,1024,2048) and output lengths (256,512,1024)
      -The generated data is completely synthetic and does not rely on real data files
      -It is suitable for pure performance benchmarking and applicable to scenarios where precise input and output lengths need to be controlled
EOF
}

model_path=""
test_data=""
device_id=""
HardWare=""
BACKEND=""
DATATYPE=""
MODELTYPE="llm"

while getopts "m:f:d:h:b:t:p:" opt; do
  case $opt in
    p)
      model_path="$OPTARG"
      ;;
    f)
      test_data="$OPTARG"
      ;;
    d)
      device_id="$OPTARG"
      ;;
    h)
      HardWare="$OPTARG"
      ;;
    b)
      BACKEND="$OPTARG"
      ;;
    t)
      DATATYPE="$OPTARG"
      ;;
    m)
      MODELTYPE="$OPTARG"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
    :)
      usage
      exit 1
      ;;
  esac
done

# 检查是否所有必需参数都已传递 ; Check whether all the necessary parameters have been passed
if [ -z "$model_path" ] || [ -z "$test_data" ] || [ -z "$device_id" ] ||\
   [ -z "$HardWare" ] || [ -z "$BACKEND" ] || [ -z "$DATATYPE" ] || [ -z "$MODELTYPE" ] ; then
  usage
  exit 1
fi

echo "Starting benchmarking with params: \
      $model_path $test_data $device_id $BACKEND $MODELTYPE $HardWare $DATATYPE "


function start_dcgm(){
  while true; do
    if curl --fail --silent --output /dev/null http://localhost:9400/metrics; then
      echo "DCGM Service Ready."
      return 0
    else
      echo "DCGM Service not Ready, starting first..."
      docker build -t dcgm:1.0 -f dcgm/Dockerfile dcgm/
      if docker ps -a --format '{{.Names}}' | grep -q "benchmark-dcgm"; then
        docker rm -f benchmark-dcgm
      fi
      docker run -d --name benchmark-dcgm --gpus all --cap-add SYS_ADMIN \
        --env DCGM_EXPORTER_COLLECTORS=/etc/dcgm-exporter/dcp-metrics.csv \
        -p 9400:9400 dcgm:1.0
      sleep 30
    fi
  done
}


function start_service(){
  local backend=$1
  local tp=$2

  if [ $backend = "lmdeploy" ]; then
    docker run -d --gpus all --env CUDA_VISIBLE_DEVICES=$device_id \
      --privileged --shm-size=10g --ipc=host \
      -v ${model_path}:/workspace/models/${model_path}  \
      -p ${service_port}:${service_port} \
      --name=${CONTAINER_NAME} ${LMDEPLOY_IMAGE_TAG} \
      lmdeploy serve api_server \
        /workspace/models/${model_path} \
        --server-name ${service_name} \
        --server-port ${service_port} \
        --tp ${tp} \
        --max-batch-size 512 \
        --cache-max-entry-count 0.9 \
        --session-len 4096

  elif [ $backend = "vllm" ]; then
    docker run -d --gpus all --env CUDA_VISIBLE_DEVICES=$device_id \
      --privileged --shm-size=10g --ipc=host \
      -v ${model_path}:/workspace/models/${model_path}  \
      -p ${service_port}:${service_port} \
      --name=${CONTAINER_NAME} ${VLLM_IMAGE_TAG} \
      python3 -m vllm.entrypoints.openai.api_server \
        --host ${service_name} \
        --port ${service_port} \
        --model /workspace/models/${model_path} \
        --dtype auto \
        -tp ${tp} \
        --max-model-len 4096 \
        --max-num-seqs 512 \
        --gpu-memory-utilization 0.9 \
        --enable-prefix-caching \
        --swap-space 16 \
        --disable-log-stats \
        --disable-log-requests \
        --trust-remote-code
#        --enforce-eager

  elif [ $backend = "tensorrt-llm" ]; then
    triton_model_repo=$(basename ${model_path%/})

    docker run -d --gpus all --env CUDA_VISIBLE_DEVICES=$device_id \
      --privileged --ipc=host --ulimit memlock=-1 --ulimit stack=67108864 \
      -v ${model_path}:/app/${triton_model_repo} \
      -p ${service_port}:${service_port} \
      --name=${CONTAINER_NAME} ${TRTLLM_IMAGE_TAG} \
      bash -c "python /app/scripts/launch_triton_server.py \
        --http_port ${service_port} \
        --model_repo ${triton_model_repo} \
        --world_size ${tp}"

  else
    echo "backend only supports vllm, lmdeploy or tensorrt-llm"
    exit
  fi

  # wait 2m minute for service ready
  sleep 2m
}


function stop_service(){
  container_id=$(docker ps -a | grep ${CONTAINER_NAME} | awk '{print $1 }')
  docker stop ${container_id}
  docker rm ${container_id}
}


function profile()
{
  local out_len=$1
  local bs=$2
  local log_path=$3
  local monitor_device_ids=$4
  local get_gpu_metrics=$5
  local model_type=${6:-llm}
  local request_rate=${7:-"inf"}  # 默认无限速率，可以传入具体值如10.0; Default infinite rate, can be passed with specific value like 10.0
  # RandomDataset专用参数（可选，有默认值）; RandomDataset dedicated parameters (optional, with default values)
  local input_len=${8:-""}        # 空值表示使用原始数据集; An empty value indicates the use of the original dataset
  local range_ratio=${9:-0.0}     # RandomDataset长度变化比例; Length change ratio for RandomDataset
  local num_requests=${10:-1000}  # RandomDataset请求数量; Number of requests for RandomDataset, Default 1000

  ## extra_body: pass other key:value pairs to the request body.
  # - for reasoning model, pass '{"reasoning_effort": "low", "include_reasoning": False}' to control output token length.
  # - for generating the request token length, pass '{"ignore_eos": True}'

  ## dataset_name: if using custom dataset, please set None, default sharegpt

  # 公共参数设置; Common parameters setup
  local common_args=""
  local extra_args=""
  common_args+="--host ${service_name} "
  common_args+="--port ${service_port} "
  common_args+="--request_output_len ${out_len} "
  common_args+="--model_type ${model_type} "
  common_args+="--batch_size ${bs} "
  common_args+="--burstiness 1.0 "
  common_args+="--top_k 3 "
  common_args+="--top_p 0.95 "
  common_args+="--temperature 0.01 "
  common_args+="--repetition_penalty 1.15 "
  common_args+="--log_path ${log_path} "
  common_args+="--debug_result true "
  common_args+="--get_gpu_metrics ${get_gpu_metrics} "
  common_args+="--get_gpu_metrics_freq 5 "
  common_args+="--enable_expand_dataset true "
  # 根据input_len是否为空判断使用哪种模式; Determine which mode to use based on whether input_len is empty
  if [ -n "$input_len" ]; then
    # RandomDataset模式特有参数; RandomDataset mode specific parameters
    extra_args+="--dataset_name random "
    extra_args+="--dataset_path dummy "
    extra_args+="--model_name_or_path ${model_path} "
    extra_args+="--num_requests ${num_requests} "
    extra_args+="--input_len ${input_len} "
    extra_args+="--range_ratio ${range_ratio} "
    extra_args+="--prefix_len 0 "
    extra_args+="--seed 42 "
    extra_args+="--vocab_limit 10000 "
    extra_args+="--request_rate ${request_rate} "
    extra_args+='--extra_body {"ignore_eos":true} '
  else
    # 原始数据集模式特有参数; Original dataset mode specific parameters
    extra_args+="--dataset_name None "
    extra_args+="--dataset_path ${test_data} "
    extra_args+="--extra_body None "
  fi

  python3 benchmark_serving.py ${common_args} ${extra_args} --device_ids "${monitor_device_ids}"
}

gpu_num=$(echo "$device_id" |grep -o "[0-9]" |grep -c "")
IFS=',' read -ra device_array <<< "$device_id"

service_name=0.0.0.0
# service_name=sg9.aip.mlp.shopee.io/aip-svc-11/test-search-civuna-1/
service_port=800

IMAGE_TAG=harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-lmdeploy:0.5.3-4a8b6d06
# IMAGE_TAG=harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-vllm:0.5.3.post1-328bc936
# IMAGE_TAG=harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-tensorrt-llm:0.10.0.dev2024043000
CONTAINER_NAME=benchmark-test

# pass $VERSION from IMAGE_TAG
VERSION="${IMAGE_TAG##*:}"
DATASET="${test_data##*/}"
model_path="${model_path%/}"
MODEL="${model_path##*/}"

for tp in 2 4;
do
  # 为了方便画图脚本解析CSV文件，用@作为分隔符; To facilitate the parsing of CSV files by the plotting script, use @ as a separator
  LOG_PATH="perf@${HardWare}@${BACKEND}@${VERSION}@${MODEL}@${DATASET}@${DATATYPE}@tp${tp}.log"
  # start dcgm to capture the GPU metrics for the local host
  # 如果不需要监控，或者调用的是远程服务，略掉这步，并且get_gpu_metrics设置False; If monitoring is not needed or the service is remote, skip this step and set get_gpu_metrics to False
  monitor_device_ids="${device_array[@]:0:$tp}"
  get_gpu_metrics=false
  if [ $get_gpu_metrics = true ]; then
    start_dcgm
  fi

  # if you want to make benchmark tests after launching server in container,
  # please COMMENT the start_service and stop_service, then modify the
  # service_name or service_port if necessary.
  start_service ${BACKEND} $tp

  # 添加测试模式选择, Add test mode selection
  REQUEST_RATE=${REQUEST_RATE:-"inf"}  # 默认无限速率; Default infinite rate
  NUM_REQUESTS=${NUM_REQUESTS:-"200"}


  if [ "$test_data" = "dummy" ]; then
    echo "=== Run benchmark with random dataset ===="

    # RandomDataset测试：可以测试不同的输入输出长度组合（标准批处理）; RandomDataset test: can test different input and output length combinations (standard batch processing)
    for input_len in 512; do
      for out_len in 256; do
        for bs in 1 2 4 8 16 32 64 128 256 512 ; do
          # 构造RandomDataset的LOG_PATH; Construct the LOG_PATH for RandomDataset
          RANDOM_LOG_PATH="perf@${HardWare}@${BACKEND}@${VERSION}@${MODEL}@RandomDataset_${input_len}_${out_len}@${DATATYPE}@tp${tp}.log"

          # 调用RandomDataset性能测试函数; Call the RandomDataset performance test function
          profile ${out_len} ${bs} ${RANDOM_LOG_PATH} "${monitor_device_ids}" ${get_gpu_metrics} ${MODELTYPE} ${REQUEST_RATE} ${input_len} 0.0 ${NUM_REQUESTS}
        done
      done
    done
  else
    echo "=== Run benchmark with business dataset ===="

    for out_len in 1024;
    do
      for bs in 1 2 4 8 16 32 64 128 256 512 ; do
        # The `1000` denotes the num requests of test_data, please set it according to the actual num.
        profile ${out_len} ${bs} ${LOG_PATH} "${monitor_device_ids}" ${get_gpu_metrics} ${MODELTYPE} ${REQUEST_RATE}
      done
    done
  fi

  stop_service
done
