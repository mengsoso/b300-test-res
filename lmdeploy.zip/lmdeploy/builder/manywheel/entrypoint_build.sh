#!/usr/bin/env bash
set -eux

export PYTHON_VERSION=$PYTHON_VERSION
export PLAT_NAME=$PLAT_NAME
export USERID=${USERID}
export GROUPID=${GROUPID}
export CUDAVER=$(nvcc --version | sed -n 's/^.*release \([0-9]\+\).*$/\1/p')
export NCCL_INCLUDE_DIR=/usr/local/cuda/include
export NCCL_LIB_DIR=/usr/local/cuda/lib64

source /opt/conda/bin/activate
conda activate $PYTHON_VERSION

cd lmdeploy
rm -rf lmdeploy/lib
mkdir -p build && cd build && rm -rf *
bash ../generate.sh make
make -j$(nproc) && make install
if [ $? != 0 ]; then
    echo "build failed"
    exit 1
fi
cd ..
rm -rf build
python setup.py bdist_wheel --cuda=${CUDAVER} --plat-name $PLAT_NAME -d /tmpbuild/
chown ${USERID}:${GROUPID} /tmpbuild/*
mv /tmpbuild/* /lmdeploy_build/
