################################################################################
# @Copyright: 2019-2025 Shopee. All Rights Reserved.
# @Author   : zhen.wan@shopee.com
# @Date     : 2025-03-04 09:09:24
# @Details  :
################################################################################
import os
import pandas as pd
from datatoolchain import load_from_hub


def load_ais_dataset(token: str, dataset_id: str, dataset_commit: str,
                     split: str="train", cache_dir: str="~/.datasets"
                     ):
    prompt_col = None
    img_col = None
    try:
        data_info = load_from_hub(dataset_id=dataset_id,
                                  commit_id=dataset_commit,
                                  cache_dir=cache_dir,
                                  split=split,
                                  use_auth_token=token,
                                  use_edit_meta_info=True,
                                  build_only_info=True)

        for col_name, info in data_info.items():
            if col_name in ["prompt", "image_url"]:
                if col_name == "prompt":
                    prompt_col = col_name
                elif col_name == "image_url":
                    img_col = col_name
                continue

            if info.get("_ais_cls_type", None) in ["AisText", "RefImage"]:
                if info.get("content_type", None) == "prompt":
                    prompt_col = col_name
                elif info.get("_type", None) == "Image":
                    img_col = col_name
                continue
    except:
        print(f"fThe dataset(id: {dataset_id}, commit_id: {dataset_commit}) " \
            "does not contain meta infomations of columns. Please click on the " \
            "'Dataset Analysis' and then use 'Column type editing' in " \
            "AIS Dataset Commit page to create.")

    dataset = load_from_hub(dataset_id=dataset_id,
                            commit_id=dataset_commit,
                            cache_dir=cache_dir,
                            split=split,
                            use_auth_token=token)
    return pd.DataFrame(dataset), prompt_col, img_col



if __name__ == "__main__":
    df, prompt_col, img_col = load_ais_dataset(token=os..getenv("AIP_TOKEN"),
                                               dataset_id="1033",
                                               dataset_commit="8982f818"
                                               )
    print(prompt_col, img_col)
