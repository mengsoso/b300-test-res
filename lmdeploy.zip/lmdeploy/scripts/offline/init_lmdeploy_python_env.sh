pip install -r requirements_cuda.txt
python3 -m pip install --no-cache-dir --trusted-host pypi.shopee.io -i http://pypi.shopee.io/simple/ "aip-infer-utils>=0.6.2"