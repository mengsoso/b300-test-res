################################################################################
# @Copyright: 2019-2025 Shopee. All Rights Reserved.
# @Author   : zhen.wan@shopee.com
# @Date     : 2025-02-28 08:15:10
# @Details  : upload perf metrics data to AIS
################################################################################
import os
import json
import fire
import requests
import pandas as pd
from urllib.parse import urljoin


def csv2json(csv_file_list_path: str):
    with open(csv_file_list_path, "r") as f:
        csv_files = [line.strip() for line in f.readlines()]

    metrics_data = {}
    for csv_file in csv_files:
        metrics = pd.read_csv(csv_file, index_col=False).to_dict(orient="records")
        # remove unused metrics
        for item in metrics:
            for metric in ["GPU UTIL", "GPU Mem (MB)", "SM Active",
                           "SM Occupancy", "DRAM Active","Request Rate",
                           "Burstiness"]:
                del item[metric]
        csv_id =os.path.splitext(os.path.basename(csv_file))[0]
        metrics_data[csv_id] = metrics

    with open("perf.json", "w", encoding="utf-8") as f:
        json.dump(metrics_data, f, indent=4, ensure_ascii=False)
    print(json.dumps(metrics_data, indent=4))
    return metrics_data


def request_server(metrics_data):
    host = os.getenv("AIP_ENDPOINT")
    project_id = os.getenv("AIP_PROJECT_ID")
    exp_id = os.getenv("AIP_EXP_ID")
    uri = f"/api/modelOptimization/v1/projects/{project_id}/modelEvaluation/evaluations/{exp_id}/update"
    url = urljoin(host, uri)

    token = os.getenv("AIP_TOKEN")
    headers = {
        'Authorization': f"Bearer {token}",
        'Content-Type': 'application/json'
    }
    data = {"resultJson": metrics_data}
    resp = requests.put(url, headers=headers, json=data)

    print(f"send request to {url}, get response code: {resp.status_code}, body: {resp.text}")


def main(csv_file_list_path: str):
    metrics_data = csv2json(csv_file_list_path)
    request_server(metrics_data)



if __name__ == "__main__":
    fire.Fire(main)
