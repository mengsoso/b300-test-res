# Copyright (c) OpenMMLab. All rights reserved.
from abc import ABC, abstractmethod
from functools import partial
from typing import List

import torch
#from aipinfer import logger
from lmdeploy.utils import get_logger
logger = get_logger('lmdeploy')

from .parameter import get_params, get_mergedmoe_params
from .source_model.base import BaseReader
from .target_model.base import BaseOutputModel
from .parameter import QuantWeightFP8


def permute_v2(x: torch.Tensor, size_per_head: int = 128):
    """
        Contract: x.size(-1) is output dims
    """

    assert x.size(-1) > 1

    output_dims = x.size(-1)
    head_num = output_dims // size_per_head

    return x.view(-1, head_num, 2, size_per_head // 2).transpose(2, 3).reshape(x.shape)


def merge_qkv_v2(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, tp: int):
    """
        Contract: x.size(-1) is output dims
    """

    def reshape(x):
        return x.view(x.size(0), tp, -1) if q.dim() == 2 else x.view(tp, -1)

    qkv = torch.cat(tuple(map(reshape, (q, k, v))), dim=-1)

    qkv = qkv.view(-1, qkv.size(-1) * tp)
    if q.dim() == 1:
        qkv.squeeze_()

    return qkv


def transpose(x):
    return x.t() if x is not None else x


def pad_out_dims(x: torch.Tensor, dims: int):
    pad = dims - x.size(-1)
    assert pad >= 0, f"pad={pad}, dims={dims}, x.size(-1)={x.size(-1)}"
    return torch.nn.functional.pad(x, (0, pad), 'constant', 0)


def pad_in_dims(x: torch.Tensor, dims: int):
    pad = dims - x.size(0)
    assert x.dim() == 2
    assert pad >= 0
    return torch.nn.functional.pad(x, (0, 0, 0, pad), 'constant', 0)


# split out dims -> copy A, split-out-dims B (qkv, w1, w3)
# split  in dims -> split-in-dims A,  copy B (  o, w2)
def get_lora_flags(kind: str):
    return ('lora_a' in kind, 'lora_b' in kind)


class Module(ABC):

    def __init__(self, model: BaseOutputModel):
        self.model = model

    def __call__(self, *args, **kwargs):
        return self.apply(*args, **kwargs)

    @abstractmethod
    def apply(self, idx: int, r: BaseReader):
        pass


class LayerNorm(Module):

    def apply(self, i: int, r: BaseReader):
        attn_norm = r.attn_norm(i)
        ffn_norm = r.ffn_norm(i)
        self.model.save_split(attn_norm, f'layers.{i}.attention_norm.weight')
        self.model.save_split(ffn_norm, f'layers.{i}.ffn_norm.weight')


class Ffn(Module):
    """
    requires:
        r.ffn(i, kind)
    """

    _ffn = 'layers.{0}.feed_forward.{1}.{2}'

    def __init__(self, model: BaseOutputModel):
        self.model = model
        self.tp = model.mlp_tp_size
        # inter_sizes in config are padded and may be different from what's
        # in the weights
        self.inter_size = model.model_config.inter_size
        self.group_size = max(1, model.model_config.group_size)
        self.model_format = model.model_config.model_format
        self.quant_algo = model.model_config.quant_algo

    def _export(self,
                inter_size: int,
                fmt: str,
                idx: int,
                w123,
                kind: str,
                pack_fn,
                apply_gs=False,
                block_size=1,
                **kwargs):
        is_lora_a, is_lora_b = get_lora_flags(kind)
        w1, w2, w3 = map(transpose, w123)

        # TODO: handle padding for block_size != 1
        if not is_lora_a and block_size == 1:
            w1 = pad_out_dims(w1, inter_size)
            w3 = pad_out_dims(w3, inter_size)
        if not is_lora_b and block_size == 1:
            group_size = self.group_size if apply_gs else 1
            w2 = pad_in_dims(w2, inter_size // group_size)

        w1, w2, w3 = map(pack_fn, (w1, w2, w3))
        self.model.save_split(w1, fmt.format(idx, 'w1', kind), split_dim=-1, split_num=self.tp, copy=is_lora_a)
        self.model.save_split(w3, fmt.format(idx, 'w3', kind), split_dim=-1, split_num=self.tp, copy=is_lora_a)
        self.model.save_split(w2, fmt.format(idx, 'w2', kind), split_dim=0, split_num=self.tp, copy=is_lora_b)

    def _export_fp8(self, fmt: str, idx: int, w123, kind: str, pack_fn):
        w1, w2, w3 = w123
        if kind == 'qweight':
            split_dim_w13 = 0
            split_dim_w2 = -1
            copy = False
        else:
            split_dim_w13 = None
            split_dim_w2 = None
            copy = True
        self.model.save_split(pack_fn(w1),
                              fmt.format(idx, 'w1', kind),
                              split_dim=split_dim_w13,
                              split_num=self.tp,
                              copy=copy)
        self.model.save_split(pack_fn(w3),
                              fmt.format(idx, 'w3', kind),
                              split_dim=split_dim_w13,
                              split_num=self.tp,
                              copy=copy)
        self.model.save_split(pack_fn(w2),
                              fmt.format(idx, 'w2', kind),
                              split_dim=split_dim_w2,
                              split_num=self.tp,
                              copy=copy)

    def _export_merged(self,
                inter_size: int,
                fmt: str,
                idx: int,
                w123,
                kind: str,
                pack_fn,
                apply_gs=False,
                block_size=1,
                **kwargs):
        w1, w2, w3 = w123
        w1, w2, w3 = map(pack_fn, (w1, w2, w3))

        self.model.save_split(w1, fmt.format(idx, 'w1', kind), split_dim=-1, split_num=self.tp)
        self.model.save_split(w3, fmt.format(idx, 'w3', kind), split_dim=-1, split_num=self.tp)
        self.model.save_split(w2, fmt.format(idx, 'w2', kind), split_dim=0, split_num=self.tp)

    def apply(self, i: int, r: BaseReader):
        for e in get_params(r.ffn(i, None), model_format=self.model_format, quant_algo=self.quant_algo):
            if self.model_format == 'fp8' and self.quant_algo == 'fp8_static':
                e(partial(self._export_fp8, self._ffn), partial(r.ffn, i), i,
                  module_type='ffn')
            else:
                e(partial(self._export, self.inter_size[i], self._ffn), partial(r.ffn, i), i)


class MoeFfn(Ffn):
    """
    requires:
        r.moe_ffn_expert(e, i, kind)
        r.moe_ffn_gate(i)
        r.moe_ffn_shared_gate(i)
    """

    _moe_ffn_expert = 'layers.{0}.moe_ffn.experts.E.{1}.{2}'
    _moe_ffn_gate = 'layers.{0}.moe_ffn.gate.weight'
    _moe_ffn_shared_gate = 'layers.{0}.moe_ffn.shared_gate.weight'

    def __init__(self, model: BaseOutputModel):
        super().__init__(model)
        self.expert_num = model.model_config.expert_num
        self.inter_size = model.model_config.expert_inter_size
        self.shared_gate = model.model_config.moe_shared_gate
        self.tp = model.moe_tp_size
        self.ep = model.moe_ep_size

    def apply(self, i: int, r: BaseReader):
        if self.expert_num[i] == 0:
            return
        # for merged moe ffn expert, only support fp16 now
        if hasattr(r, 'merged_moe_ffn_expert'):
            for p in get_mergedmoe_params(r.merged_moe_ffn_expert(), model_format=self.model_format, quant_algo=self.quant_algo):
                for e in range(self.expert_num[i] * self.ep):
                    fmt = self._moe_ffn_expert.replace('E', str(e))
                    p(f=partial(self._export_merged, self.inter_size, fmt), 
                    g=partial(r.merged_moe_ffn_expert, e, i, self.expert_num[i]), 
                    i=i)
        else:
            for p in get_params(r.moe_ffn_expert(), model_format=self.model_format, quant_algo=self.quant_algo):
                for e in range(self.expert_num[i] * self.ep):
                    fmt = self._moe_ffn_expert.replace('E', str(e))

                    if self.model_format == 'fp8' and self.quant_algo == 'fp8_static':
                        p(partial(self._export_fp8, fmt), partial(r.moe_ffn_expert, e, i),
                        i, module_type='ffn')
                    else:
                        p(partial(self._export, self.inter_size, fmt),
                        partial(r.moe_ffn_expert, e, i), i)

        gate = transpose(r.moe_ffn_gate(i))
        self.model.save_split(gate, self._moe_ffn_gate.format(i))

        if self.shared_gate:
            shared_gate = transpose(r.moe_ffn_shared_gate(i))
            # print(shared_gate)
            self.model.save_split(shared_gate, self._moe_ffn_shared_gate.format(i))


class Attn(Module):
    """
    requires:
        r.attn(i, kind)
    """

    _attn = 'layers.{0}.attention.{1}.{2}'

    def __init__(self, model: BaseOutputModel):
        self.model = model
        self.tp = model.attn_tp_size
        self.head_dim = model.model_config.size_per_head
        self.attn_bias = model.model_config.attn_bias
        self.qk_norm = model.model_config.qk_norm
        self.model_format = model.model_config.model_format
        self.quant_algo = model.model_config.quant_algo

    def _reorder_and_merge(self, qkvo, block_size, kind='qweight'):
        if self.model_format == 'fp8' and self.quant_algo == 'fp8_static':
            # don't need transpose o for TN FP8 Gemm
            qkv, o = qkvo[:-1], qkvo[-1]
            q, k, v = map(transpose, qkv)
        else:
            q, k, v, o = qkvo
        # reorder output dim for tm's rotary embedding layout
        if self.model.permute_qk:
            if block_size == 1:
                q = permute_v2(q, self.head_dim)
                k = permute_v2(k, self.head_dim)
            else:
                assert block_size % self.head_dim == 0
        qkv = merge_qkv_v2(q, k, v, self.tp)
        if self.model_format == 'fp8' and self.quant_algo == 'fp8_static' and kind == 'qweight':
            # transpose tensor after merge_qkv, for TN FP8 GemmW
            qkv = transpose(qkv)
        # zero bias for `wo` when `w_qkv` has bias but `wo` doesn't
        if o is None and q.dim() == 1:
            o = torch.zeros_like(q)
        return qkv, o

    def _repeat_kv(self, qkvo, kind: str):
        """Replicate kv."""
        q, k, v, o = qkvo
        head_dim = self.model.model_config.size_per_head
        hidden_dim = self.model.model_config.hidden_units

        def _repeat(x):
            dim = hidden_dim if kind != 'bias' else 1
            x = x.reshape(dim, -1, head_dim)
            x = x.repeat(1, 1, self.model.repeat_kv)
            x = x.reshape(dim, -1)
            return x

        k, v = map(_repeat, (k, v))
        if kind == 'bias':
            if o is None:
                o = torch.zeros(hidden_dim, dtype=q.dtype, device=q.device)
            q, k, v, o = map(torch.squeeze, (q, k, v, o))

        return (q, k, v, o)

    def _export(self, idx: int, qkvo, kind: str, pack_fn, block_size=1, **kwargs):
        if all(x is None for x in qkvo):
            return
        is_lora_a, is_lora_b = get_lora_flags(kind)
        if is_lora_a:
            qkv, o = map(transpose, qkvo)
        else:
            qkvo = tuple(map(transpose, qkvo))
            if self.model.repeat_kv:
                qkvo = self._repeat_kv(qkvo, kind)
            qkv, o = self._reorder_and_merge(qkvo, block_size)
        self.model.save_split(pack_fn(qkv),
                              self._attn.format(idx, 'w_qkv', kind),
                              split_dim=-1,
                              split_num=self.tp,
                              copy=is_lora_a)
        self.model.save_split(pack_fn(o),
                              self._attn.format(idx, 'wo', kind),
                              split_dim=0,
                              split_num=self.tp,
                              copy=is_lora_b)

    def _export_fp8(self, idx: int, qkvo, kind: str, pack_fn, block_size=1, **kwargs):
        if all(x is None for x in qkvo):
            return
        if kind in ['qweight', 'bias']:
            qkv, o = self._reorder_and_merge(qkvo, block_size, kind=kind)

            if kind == 'bias':
                self.model.save_split(pack_fn(qkv),
                                      self._attn.format(idx, 'w_qkv', kind),
                                      split_dim=-1,
                                      split_num=self.tp,
                                      copy=False)
                self.model.save_split(pack_fn(o),
                                      self._attn.format(idx, 'wo', kind),
                                      split_dim=None,
                                      copy=True)
            else:
                self.model.save_split(pack_fn(qkv),
                                      self._attn.format(idx, 'w_qkv', kind),
                                      split_dim=0,
                                      split_num=self.tp,
                                      copy=False)
                self.model.save_split(pack_fn(o),
                                      self._attn.format(idx, 'wo', kind),
                                      split_dim=-1,
                                      split_num=self.tp,
                                      copy=False)
        else:
            layer_type, scale_type = kind.split('.') # w_qkv/wo, weight/input_scale
            self.model.save_split(pack_fn(qkvo),
                                  self._attn.format(idx, layer_type, scale_type),
                                  split_dim=None,
                                  split_num=self.tp,
                                  copy=True)

    def apply(self, i: int, r: BaseReader):
        for e in get_params(r.attn(i, None), bias=self.attn_bias,
                            model_format=self.model_format, quant_algo=self.quant_algo):
            if self.model_format == 'fp8' and self.quant_algo == 'fp8_static' and isinstance(e, QuantWeightFP8):
                e(self._export_fp8, partial(r.attn, i), i, module_type='attn')
            else:
                e(self._export, partial(r.attn, i), i)

        if self.qk_norm:
            q, k = r.qk_norm(i)
            if self.model.permute_qk:
                q = permute_v2(q, self.head_dim)
                k = permute_v2(k, self.head_dim)
            self.model.save_split(q, self._attn.format(i, 'q_norm', '')[:-1])
            self.model.save_split(k, self._attn.format(i, 'k_norm', '')[:-1])


class MLA(Module):
    """
    requires:
        r.mla(i, kind)
        r.mla_norm(i)
    """

    _mla = 'layers.{0}.attention.{1}.{2}'

    def __init__(self, model: BaseOutputModel):
        self.model = model

    # TODO(Alan): not support quant algo yet
    def _export(self, idx: int, xs, kind: str, pack_fn, **kwargs):
        if all(x is None for x in xs):
            return
        q_a, q_b, q, kv_a, kv_b, o = map(transpose, xs)

        if q is not None:
            q_b = q

        cfg = self.model.model_config

        o = o.reshape(cfg.head_num, cfg.v_head_dim, -1)
        o = torch.nn.functional.pad(o, (0, 0, 0, cfg.size_per_head - cfg.v_head_dim, 0, 0))
        o = o.view(cfg.head_num * cfg.size_per_head, cfg.hidden_units)

        tp = self.model.attn_tp_size

        if q_a is not None:
            self.model.save_split(pack_fn(q_a), self._mla.format(idx, 'q_a_proj', kind))
        q_b_name = 'q_proj' if q_a is None else 'q_b_proj'
        self.model.save_split(pack_fn(q_b), self._mla.format(idx, q_b_name, kind), split_dim=-1, split_num=tp)
        self.model.save_split(pack_fn(kv_a), self._mla.format(idx, 'kv_a_proj', kind))
        self.model.save_split(pack_fn(kv_b), self._mla.format(idx, 'kv_b_proj', kind), split_dim=-1, split_num=tp)
        self.model.save_split(pack_fn(o), self._mla.format(idx, 'wo', kind), split_dim=0, split_num=tp)

    _layernorm = 'layers.{0}.attention.{1}_a_layernorm'

    def apply(self, i: int, r: BaseReader):

        for f in get_params(r.attn(i, None), bias=False):
            f(self._export, partial(r.mla, i), i)

        q, k = r.mla_norm(i)
        if q is not None:
            self.model.save_split(q, self._layernorm.format(i, 'q'))
        self.model.save_split(k, self._layernorm.format(i, 'kv'))


class Misc(Module):
    """
    requires:
        r.tok_embeddings()
        r.norm_weight()
        r.output_weight()
    """

    def apply(self, i: int, r: BaseReader):
        """Export embedding, norm, output weight."""
        emb = r.tok_embeddings()
        norm_weight = r.norm_weight()
        output_weight = r.output_weight()

        def pad_weight(tensor: torch.Tensor, tp: int):
            pad_size = None
            vocab_size = self.model.model_config.vocab_size
            if vocab_size % tp != 0:
                pad_size = (vocab_size + tp - 1) // tp * tp - vocab_size
            if pad_size is None:
                return tensor
            return torch.nn.functional.pad(tensor, (0, 0, 0, pad_size), 'constant', 0)

        if emb is not None:
            tp = self.model.attn_tp_size
            emb = pad_weight(emb, tp=tp)
            self.model.save_split(emb, 'tok_embeddings.weight', split_dim=1, split_num=tp)
        if norm_weight is not None:
            self.model.export_weight(norm_weight, 'norm.weight')
        if output_weight is not None:
            if self.model.model_config.use_normhead:
                logger.info('use_normhead=True, normalize weights')
                output_weight = torch.nn.functional.normalize(output_weight)
            tp = self.model.attn_tp_size
            output_weight = pad_weight(output_weight, tp=tp)
            # transpose
            self.model.save_split(output_weight.t(), 'output.weight', split_dim=1, split_num=tp)


class Transformer:

    def __init__(self, model: BaseOutputModel):
        self.model = model
        modules = [LayerNorm]
        if model.model_config.kv_lora_rank:
            modules.append(MLA)
        else:
            modules.append(Attn)
        if model.model_config.inter_size:
            modules.append(Ffn)
        if model.model_config.expert_num:
            modules.append(MoeFfn)
        self.modules = [c(model) for c in modules]
        self.misc = Misc(model)

    def __call__(self, i: int, r: BaseReader):
        if i >= 0:
            for m in self.modules:
                m(i, r)
            return 1
        else:
            self.misc(i, r)
