#!/user/bin/env bash
################################################################################
# @Copyright: 2024 Shopee. All Rights Reserved.
# @Author   : zhen.wan@shopee.com
# @Date     : 2025-02-26 10:47:20
# @Details  : benchmark test script for openai compatible server on AIS
################################################################################
set -euxo pipefail


function profile()
{
  local model_type=$1
  local host=$2
  local req_token_len=$3
  local bs=$4
  local top_k=$5
  local top_p=$6
  local temperature=$7
  local repetition_penalty=$8
  local log_path=$9
  local extra_args=${10:-""}

  python3 ${SCRIPT_DIR}/benchmark_serving.py \
      --model_type ${model_type} \
      --host ${host} \
      --request_output_len ${req_token_len} \
      --batch_size ${bs} \
      --top_k ${top_k} \
      --top_p ${top_p} \
      --temperature ${temperature} \
      --repetition_penalty ${repetition_penalty} \
      --log_path ${log_path} \
      --enable_expand_dataset true ${extra_args}
}


# for local test
if false; then
  export TASK_TYPE=llm

  export SERVICE_INVOCATION_URL=sg12.aip.mlp.shopee.io/services/185719/ #205627/
  extra_args=""
  #export SERVICE_INVOCATION_URL=0.0.0.0
  #extra_args="--port 888"

  #export DATASETS='[{"id": 1033, "commit_id": "8982f818", "top_k": 3, "top_p": 0.95, "temperature": 0.01, "repetition_penalty": 1.15},{"id": 1037,"commit_id": "709e9e47", "top_k": 20,"top_p": 0.8,"temperature": 0.1, "repetition_penalty": 1.05}]'
  #export HESTIA_URL="http://ais.mlp.test.shopee.io/api/mfp-dataset-warehouse/"
  #export DATASETS='[{"id": 1033, "commit_id": "8982f818", "top_k": 3, "top_p": 0.95, "temperature": 0.01, "repetition_penalty": 1.15}]' # data_200.csv on mlp_test
  #export DATASETS='[{"id": 1034, "commit_id": "fbca9f80", "top_k": 3, "top_p": 0.95, "temperature": 0.01, "repetition_penalty": 1.15}]' # vlm_data.csv on mlp_test

  export DATASETS='[{"id": 4556, "commit_id": "6eba879e", "top_k": 20, "top_p": 0.8, "temperature": 0.1, "repetition_penalty": 1.05}]' # data_200.csv on mlp
  #export DATASETS='[{"id": 4540, "commit_id": "87d87bab", "top_k": 20, "top_p": 0.8, "temperature": 0.1, "repetition_penalty": 1.05}]' # chatbot_taskbot3_1k on mlp
  #export DATASETS='[{"id": 4573, "commit_id": "daf48ecb", "top_k": 3, "top_p": 0.95, "temperature": 0.01, "repetition_penalty": 1.15}]' # vlm_data.csv on mlp

  # please `export AIP_TOKEN=xxx` to access AIS
  export AIP_ENDPOINT=https://ais.mlp.test.shopee.io
  export AIP_PROJECT_ID=83
  export AIP_EXP_ID=837
  export BATCH_SIZE="16 32"
  export REQ_GEN_LEN="256"
fi


env_vars=("TASK_TYPE" "SERVICE_INVOCATION_URL" "DATASETS" "AIP_TOKEN" "BATCH_SIZE" "REQ_GEN_LEN")
for var in ${env_vars[@]}; do
  if [[ -v ${var} ]]; then
    echo "$var=${!var}"
  else
    echo "The environment variable $var does not exist. Please set it."
    exit 1
  fi
done

SCRIPT_DIR=$(dirname "$(readlink -f "$0")")


echo "$DATASETS" | jq -c '.[]' | while read -r dataset; do
  #dataset info
  id=$(echo "$dataset" | jq -r '.id')
  commit_id=$(echo "$dataset" | jq -r '.commit_id')

  export AIP_DATASET_ID=$id
  export AIP_DATASET_COMMIT_ID=$commit_id

  # sample parameters
  top_k=$(echo "$dataset" | jq -r '.top_k')
  top_p=$(echo "$dataset" | jq -r '.top_p')
  temperature=$(echo "$dataset" | jq -r '.temperature')
  repetition_penalty=$(echo "$dataset" | jq -r '.repetition_penalty')

  log_name="perf-dataset-$id-$commit_id.log"

  echo "===================== Run dataset: id=$id, commit_id=$commit_id ====================="
  echo "sample parameters: top_k=$top_k, top_p=$top_p, temperature=$temperature, repetition_penalty=$repetition_penalty"

  for out_len in $REQ_GEN_LEN; do
    for bs in $BATCH_SIZE; do
      profile $TASK_TYPE $SERVICE_INVOCATION_URL $out_len $bs $top_k $top_p $temperature $repetition_penalty $log_name
    done
  done
done


# print perf data and genernated text on screen and upload metrics data to AIS
mapfile -t jsonl_files < <(ls *.jsonl 2>/dev/null)
for jsonl_file in ${jsonl_files[@]}; do echo "$jsonl_file" && tail -n 5 "$jsonl_file"; done

csv_file_path=csv_list.txt
mapfile -t csv_files < <(find . -maxdepth 1 -type f -name "*.csv")
printf "%s\n" "${csv_files[@]}" > ${csv_file_path}
for csv_file in ${csv_files[@]}; do echo "$csv_file" && cat "$csv_file"; done

python3 ${SCRIPT_DIR}/utils/ais_upload_benchmark.py --csv_file_list_path ${csv_file_path}
