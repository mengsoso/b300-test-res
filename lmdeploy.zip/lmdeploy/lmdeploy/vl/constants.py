# Copyright (c) OpenMMLab. All rights reserved.
IMAGE_DUMMY_TOKEN_INDEX = 0
IMAGE_TOKEN = '<IMAGE_TOKEN>'
