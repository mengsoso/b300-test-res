<div align="center">

Benchmarks-LLM
===========================
<h4> A Benchmark Toolbox for LLM Inference Performance.</h4>

---
<div align="left">

## Latest News 🔥
- [2024/08/22] Add [data visualization tool](https://git.garena.com/shopee/MLP/aip/llm-sys/benchmarks-llm-chart-tool) to draw graph.
- [2024/08/21] Support performance benchmark for VLMs with [openai-chat](https://platform.openai.com/docs/api-reference/chat/create) API.
- [2024/08/16] Support dynamic dataset expansion when the number of test data samples $`< 200`$ or when the test concurrency (batch size) is large.
- [2024/08/13] Support loading test data for [AIS dataset](https://ais.mlp.shopee.io/projects/data/dataset?current=1&pageSize=10&projectId=11&type=all).
- [2024/08/07] Support using [DCGM](https://developer.nvidia.com/dcgm) to capture GPU metrics when running local test.
- [2024/05/21] Added support for inference performance benchmark with [LMDeploy](https://github.com/InternLM/lmdeploy), [vLLM](https://github.com/vllm-project/vllm/) and [TensorRT-LLM](https://github.com/NVIDIA/TensorRT-LLM).
- [2024/05/14] We officially released Benchmarks-LLM!


## Benchmarks-LLM Overview

Benchmarks-LLM is an easy-to-use toolbox for benchmarking Large Language Models (LLMs) performance on inference. It benchmarks LLMs service deployed with inference frameworks (e.g., [TensorRT-LLM](https://github.com/NVIDIA/TensorRT-LLM), [lmdeploy](https://github.com/InternLM/lmdeploy) and [vLLM](https://github.com/vllm-project/vllm)) under different batch sizes and generation lengths, and then outputs the performance data to a CSV file.

Benchmarks-LLM performs performance stress testing by invoking the OpenAI-compatible interface ([`/v1/completions`](https://platform.openai.com/docs/api-reference/completions/create) or [`/v1/chat/completions`](https://platform.openai.com/docs/api-reference/chat/create)) provided by the LLM frameworks (like [lmdeploy](https://github.com/InternLM/lmdeploy) and [vLLM](https://github.com/vllm-project/vllm)). The metrics collected include:
- Successful Request num
- Request_Gen_Token_Len
- Batch Size
- Avg_Input_Token_Len
- Avg_Gen_Token_Len
- Elapse_Time (s)
- TTFT (Time to First Token) AVG/P99
- TPOT (Time per Output Token) AVG/P99
- Latency P90/P95/P99/AVG
- Token Throughput (token/s)
- Service Throughput (req/s)
- Decode Token Throughput (token/user/s)
- GPU metrics: UTIL, Mem (MB), SM Active, SM Occupancy, and DRAM Active

## Getting Started

### Prepare for dataset

You can download the ShareGPT dataset by running:

```bash
wget https://huggingface.co/datasets/anon8231489123/ShareGPT_Vicuna_unfiltered/resolve/main/ShareGPT_V3_unfiltered_cleaned_split.json
```
Or use the [200 cases](https://ais.mlp.shopee.io/projects/data/dataset/commit/detail?commitId=647e624b&did=3580&projectId=11&tab=basic-information) from [AIS dataset](https://ais.mlp.shopee.io/projects/data/dataset?current=1&pageSize=10&projectId=11&type=all) by setting environmental variables:

```bash
# please refer to docs: https://docs.google.com/document/d/1AAHvx2DnXIX7DgjCJKg6RBgpZ2-3lHQM3CyUFkNYmiI/edit to create your own dataset
export AIP_TOKEN=$(Your AIS Personal Access Token)
export AIP_DATASET_ID=3580
export AIP_DATASET_COMMIT_ID=647e624b
```

### Container environment

Available images:

| Image                                                             | Tag                              |
|-------------------------------------------------------------------|----------------------------------|
| harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-lmdeploy | bef35fb3                         |
| harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-vllm     | 0.5.4-850052ba                   |
| registry.cn-beijing.aliyuncs.com/devel-img/tensorrt-llm           | 0.12.0.dev2024071600-arch_808990 |


### Run benchmarks

```bash
# Clone project
git clone --recursive --remote https://git.garena.com/shopee/MLP/aip/llm-sys/benchmarks-llm.git
cd benchmarks-llm && pip3 install -r requirements.txt
```

```bash
# Run benchmark on local machine (Recommended)

# Step 1. Choose one of the following image tag and start container
IMAGE_TAG=harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-lmdeploy:bef35fb3 # 0.5.3
IMAGE_TAG=harbor.shopeemobile.com/aip/shopee-mlp-aip-llm-generater-vllm:0.5.4-15d8d1a3
IMAGE_TAG=registry.cn-beijing.aliyuncs.com/devel-img/tensorrt-llm:0.12.0.dev2024071600-arch_808990
# for lmdeploy and vllm
docker run -it --gpus all --privileged --shm-size=10g \
            --ipc=host \
            -v ${PWD}:/workspace \
            -v /data/models:/data \
            -p 800:800 \
            --rm --name=benchmark-test ${IMAGE_TAG} /bin/bash

# for tensorrt-llm
docker run -it --gpus all --privileged \
            --network=host --ipc=host --ulimit memlock=-1 --ulimit stack=67108864 \
            -v ${PWD}:/workspace \
            -v /data:/data \
            -p 800:800 \
            --rm --name=benchmark-test ${IMAGE_TAG} /bin/bash


# Step 2. Start the service based on the framwork, model, accuracy, and other related parameter settings.
# for example:
lmdeploy serve api_server ${model_path} --server-name ${service_name} --server-port ${service_port} \
  --tp ${tp_size} --cache-max-entry-count 0.9 --session-len 4096 --max-batch-size 256 --enable-prefix-caching

python3 -m vllm.entrypoints.openai.api_server --host ${host_name} --port $port --model ${model_path} \
  -tp ${tp_size} --max-model-len 4096 --max-num-seqs 512 --gpu-memory-utilization 0.9 \
  --swap-space 16 --trust-remote-code --disable-log-stats --disable-log-requests

python /app/scripts/launch_triton_server.py --http_port ${http_port} --grpc_port ${grpc_port} \
  --metrics_port ${metrics_port} --model_repo=${triton_model_repo} --world_size ${tp_size}

### Of course, you can also finish Step 1 and Step 2 together by directly setting the image tag and start the service in the background with benchmark_serving.sh


# Step 3. Run benchmark
# if the service started in the background, the function `start_service` and `stop_service` at line 241 and 251 in benchmark_serving.sh should be COMMENTED!!!
bash benchmark_serving.sh -p /path/to/model -m model_type(llm/vllm) -f /path/to/test_dataset -d device_id(0,1) \
  -b backend(choose from lmdeploy/vllm/tensorrt-llm） -h hardware_type(like h100) -t model_precision(like fp16)
```


```bash
# Run benchmark for service deployed on AIS

# Step 1. Modify the service information in benchmark_serving.sh:
#         - Configure `service_name` and `service_port` according to the invocation description of service on AIS
#         - COMMENT the function `start_dcgm`, `start_service` and `stop_service`, set `get_gpu_metrics=False`

# Step 2. Run benchmark
bash benchmark_serving.sh -p /path/to/model -m model_type(llm/vllm) -f /path/to/test_dataset -d device_id(0,1) \
  -b backend(choose from lmdeploy/vllm/tensorrt-llm） -h hardware_type(like h100) -t model_precision(like fp16)
```


## Data Visualization
```bash
cd graph_maker_tool
python begin.py --csv-paths "perf@H100@lmdeploy@ede89a76@vicuna-13b@query.jsonl@fp16@tp1.csv" "perf@H100@lmdeploy@ede89a76@vicuna-13b@query.jsonl@fp16@tp2.csv" \
  --indicators "Token Throughput (token/s)" --baseline 0 --bar-label --full-name --rounding
# The `--baseline` argument specifies the index of the CSV file that you want to use as the baseline data.
# The `--rounding` argument applied `round` to each data
# For a full list of options, use: `python3 begin.py --help`
```
