# Copyright (c) OpenMMLab. All rights reserved.
from .entrypoint import run

__all__ = ['run']
