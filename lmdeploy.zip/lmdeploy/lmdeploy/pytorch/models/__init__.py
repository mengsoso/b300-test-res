# Copyright (c) OpenMMLab. All rights reserved.
from .q_modules import QLinear, QRMSNorm

__all__ = ['QLinear', 'QRMSNorm']
