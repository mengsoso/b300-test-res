# Copyright (c) OpenMMLab. All rights reserved.
from .utils import load_image

__all__ = ['load_image']
