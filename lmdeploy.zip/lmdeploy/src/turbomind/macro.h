#pragma once

#if !defined(__PRETTY_FUNCTION__) && !defined(__GNUC__)

#define __PRETTY_FUNCTION__ __FUNCSIG__

#endif

typedef unsigned int uint;
